# Katkıda Bulunma

Bu projeye katkıda bulunmak istiyorsanız hoş geldiniz! Birkaç yol var:

## Hata bildirimi

[Issues](../../issues) sekmesinden yeni bir issue açın. Şu bilgileri ekleyin:

- Dağıtım ve sürüm (örn. Fedora 43, Ubuntu 24.04)
- Masaüstü ortamı (GNOME 49, KDE Plasma 6 vb.)
- Oturum tipi (X11 / Wayland)
- Ne yapmaya çalıştığınız ve ne olduğu
- Hata mesajları (varsa)

`docs/sorun-giderme.md` dosyasının sonundaki teşhis komutlarının çıktısını da yapıştırırsanız çözüm hızlanır.

## Yeni transliterasyon sistemi varyantı ekleme

Bu repo şu an sadece **TDV İA** sistemini destekliyor. Diğer akademik sistemler için ayrı varyantlar eklenebilir:

- **DMG** (Alman Şarkiyat) — `tr(ottoman-dmg)`
- **IJMES** (uluslararası Orta Doğu çalışmaları) — `tr(ottoman-ijmes)`
- **EI3** (Brill Encyclopaedia of Islam) — `tr(ottoman-ei)`
- **ALA-LC** (Library of Congress) — `tr(ottoman-loc)`

Yeni varyant eklemek için:

1. `src/` altına yeni snippet dosyası: `tr-ottoman-{sistem}.xkb`
2. `docs/transliterasyon-sistemi.md` dosyasını güncelle, yeni sistemi açıkla
3. `scripts/install.sh` içine seçim mekanizması ekle (veya ayrı kurulum scripti)
4. Pull request gönder

## XKB değişiklikleri için

XKB tuş atamalarını değiştirirken **mutlaka** `scripts/test.sh` ile syntax testi yapın:

```bash
bash scripts/test.sh
```

Test geçmeden PR göndermeyin. CI/CD da otomatik test yapar ama yerel testle başlayın.

### Tuş seçimi felsefesi

Tuş atamalarında şu prensipleri koruyun:

1. **Türkçe Q yazımını bozma** — ı, i, ç, ğ, ö, ş, ü tuşlarının level 1-2'sine dokunma
2. **Sezgisellik** — `s` tuşu `ṣ`'ye, `t` tuşu `ṭ`'ye gibi
3. **Tutarlılık** — benzer karakterler benzer mantıkla (alt nokta, üst nokta vb.)
4. **Çakışma yok** — aynı tuşa iki farklı karakter atama

## Belge çevirileri

README ve docs şu an Türkçe. Şu çevirilere ihtiyaç var:

- İngilizce (uluslararası akademisyenler için)
- Almanca (Şarkiyat geleneği için)
- Arapça

Çeviri PR'ları için `README.en.md`, `docs/en/` gibi yapı kullanın.

## Yeni dağıtım/DE testi

[docs/compatibility.md](docs/compatibility.md) dosyasına yeni dağıtım/masaüstü ortamı testleri eklemek faydalı. Test ettiğiniz ortamı ve sonucu issue olarak bildirin, biz de tabloya ekleyelim.

## Geliştirme ortamı

Bu repo'yu yerel olarak geliştirmek için ihtiyacınız olanlar:

```bash
# Fedora
sudo dnf install xkbcomp xkeyboard-config python3

# Ubuntu/Debian
sudo apt install x11-xkb-utils xkb-data python3
```

## Lisans

Bu repoya katkıda bulunarak, katkınızın **GPL-3.0** lisansı altında dağıtılacağını kabul edersiniz.

## Davranış kuralları

Saygılı ve yapıcı olun. Akademik bir araç olduğu için tartışmalar bilimsel olabilir; eleştiriler kişiselleşmemeli. Tüm meşru transliterasyon gelenekleri (İA, DMG, IJMES vb.) bu projede yer bulabilir.
