# Sürüm Geçmişi

Bu dosya [Keep a Changelog](https://keepachangelog.com/tr/1.0.0/) formatına uyar.
Sürüm numaralandırması [Semantic Versioning](https://semver.org/lang/tr/) standardını takip eder.

## [Yayımlanmamış]

## [1.0.0] - 2026-04-29

### İlk sürüm

- Türkçe Q tabanlı XKB varyantı: `tr(ottoman)`
- TDV İslam Ansiklopedisi (İA) transliterasyon sistemi
- AltGr seviyesinde Osmanlıca/Arapça transkripsiyon karakterleri
- Tüm uzun ünlüler: ā ē ī ō ū
- Tüm vurgulu ünsüzler: ṣ ḍ ṭ ẓ ḥ ḳ
- Hırıltı/gırtlak: ḫ ġ
- Şapkalı ünlüler: â î û
- Alt-çizgili ünsüzler: ẕ ḏ ż
- Bileşik karakterler: s̱, ı̄ (combining marks ile)
- Nazal n: ñ
- Ayn (ʿ U+02BF) ve hemze (ʾ U+02BE) — TDV resmi
- Çoklu dağıtım uyumlu kurulum scripti
- Otomatik yedek alma ve geri alma mekanizması
- xkbcomp ile syntax doğrulama
- GNOME, KDE, XFCE, Cinnamon, MATE desteği (X11 + Wayland)
