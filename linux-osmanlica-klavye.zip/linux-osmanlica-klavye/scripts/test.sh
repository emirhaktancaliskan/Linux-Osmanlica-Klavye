#!/bin/bash
# Linux Osmanlıca Transkripsiyon Klavyesi — Test
# Sistem dosyalarına dokunmadan XKB syntax'ını test eder.

set -e

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
SNIPPET_FILE="$SCRIPT_DIR/../src/tr-ottoman-snippet.xkb"

GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

if [ ! -f "$SNIPPET_FILE" ]; then
    echo -e "${RED}HATA${NC}: tr-ottoman-snippet.xkb bulunamadı: $SNIPPET_FILE"
    exit 1
fi

if ! command -v xkbcomp >/dev/null 2>&1; then
    echo -e "${RED}HATA${NC}: xkbcomp gerekli."
    echo "  Fedora:    sudo dnf install xkbcomp"
    echo "  Ubuntu:    sudo apt install x11-xkb-utils"
    echo "  Arch:      sudo pacman -S xkbcomp"
    exit 1
fi

echo "Test: XKB syntax doğrulaması"

# Geçici test keymap'i oluştur
TEST_KEYMAP=$(mktemp /tmp/xkb-test-XXXXXX.xkb)
TEST_OUT=$(mktemp /tmp/xkb-test-XXXXXX.xkm)
TEST_ERR=$(mktemp /tmp/xkb-test-XXXXXX.err)

# Snippet'ten "xkb_symbols ... { ... };" bloğunu çıkar
SYMBOLS_BODY=$(awk '/^xkb_symbols/,/^};/' "$SNIPPET_FILE")

# Tam keymap içine yerleştir
cat > "$TEST_KEYMAP" <<EOF
xkb_keymap {
  xkb_keycodes  { include "evdev+aliases(qwerty)" };
  xkb_types     { include "complete" };
  xkb_compat    { include "complete" };
  xkb_geometry  { include "pc(pc105)" };

  $SYMBOLS_BODY
};
EOF

# Test çalıştır
TEST_RESULT=0
xkbcomp -xkb "$TEST_KEYMAP" "$TEST_OUT" 2>"$TEST_ERR" || TEST_RESULT=$?

# Gerçek hataları filtrele
ERRORS=$(grep -iE "error|expected|undefined" "$TEST_ERR" 2>/dev/null | grep -v "No symbols defined" | grep -v "redefined" || true)

# Temizle
rm -f "$TEST_KEYMAP" "$TEST_OUT" "$TEST_ERR"

if [ -n "$ERRORS" ] || [ $TEST_RESULT -ne 0 ]; then
    echo -e "${RED}✗ TEST BAŞARISIZ${NC}"
    echo ""
    echo "$ERRORS"
    exit 1
fi

echo -e "${GREEN}✓ TEST GEÇTİ${NC}"
echo ""
echo "tr-ottoman-snippet.xkb syntax açısından temiz."
