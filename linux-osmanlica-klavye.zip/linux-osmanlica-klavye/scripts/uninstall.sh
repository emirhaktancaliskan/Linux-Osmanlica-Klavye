#!/bin/bash
# Linux Osmanlıca Transkripsiyon Klavyesi — Kaldırma
# Lisans: GPL-3.0

set -e

SYMBOLS_FILE="/usr/share/X11/xkb/symbols/tr"
RULES_FILE="/usr/share/X11/xkb/rules/evdev.xml"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}HATA${NC}: 'sudo bash $0' ile çalıştırın."
    exit 1
fi

echo "=================================================="
echo "  Osmanlıca Klavye — Kaldırma"
echo "=================================================="
echo ""

# Yöntem 1: En son yedekten geri yükle
LATEST=$(ls -dt /usr/share/X11/xkb/backup-* 2>/dev/null | head -1)

if [ -n "$LATEST" ] && [ -f "$LATEST/tr" ] && [ -f "$LATEST/evdev.xml" ]; then
    echo "→ Yedekten geri yükleniyor: $LATEST"
    cp "$LATEST/tr" "$SYMBOLS_FILE"
    cp "$LATEST/evdev.xml" "$RULES_FILE"
    echo -e "${GREEN}✓ Yedekten geri yüklendi${NC}"
else
    echo -e "${YELLOW}→ Yedek bulunamadı.${NC}"
    echo "  Manuel temizleme deneniyor..."

    # symbols dosyasından ottoman bloğunu sil
    if grep -q 'xkb_symbols "ottoman"' "$SYMBOLS_FILE"; then
        sed -i '/xkb_symbols "ottoman"/,/^};/d' "$SYMBOLS_FILE"
        echo "  symbols dosyasından kaldırıldı"
    fi

    # evdev.xml'den ottoman variant bloğunu sil
    if grep -q '<name>ottoman</name>' "$RULES_FILE"; then
        python3 <<'PYEOF'
import re
rules_path = "/usr/share/X11/xkb/rules/evdev.xml"
with open(rules_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Ottoman variant bloğunu sil
pattern = r'\s*<variant>\s*<configItem>\s*<name>ottoman</name>.*?</variant>'
new_content = re.sub(pattern, '', content, flags=re.DOTALL)

with open(rules_path, 'w', encoding='utf-8') as f:
    f.write(new_content)
print("  evdev.xml'den kaldırıldı")
PYEOF
    fi

    # XML hâlâ geçerli mi?
    if ! python3 -c "import xml.etree.ElementTree as ET; ET.parse('$RULES_FILE')" 2>/dev/null; then
        echo -e "${YELLOW}→ XML bozuldu, paketi yeniden kuruyorum...${NC}"
        if command -v dnf >/dev/null 2>&1; then
            dnf reinstall -y xkeyboard-config
        elif command -v apt-get >/dev/null 2>&1; then
            apt-get install --reinstall -y xkeyboard-config
        elif command -v pacman >/dev/null 2>&1; then
            pacman -S --noconfirm xkeyboard-config
        elif command -v zypper >/dev/null 2>&1; then
            zypper install -f -y xkeyboard-config
        else
            echo -e "${RED}HATA${NC}: Paket yöneticisi tanınmadı. xkeyboard-config'ı manuel yeniden kurun."
            exit 1
        fi
    fi

    echo -e "${GREEN}✓ Temizlendi${NC}"
fi

echo ""
echo "=================================================="
echo -e "${GREEN}✓ Kaldırma tamamlandı${NC}"
echo "=================================================="
echo ""
echo "Logout/login yapın. Klavye ayarlarınızdan Ottoman"
echo "varyantını da kaldırmanız gerekebilir."
echo ""
