#!/bin/bash
# Linux Osmanlıca Transkripsiyon Klavyesi — Kurulum
# Lisans: GPL-3.0
#
# Yedek alır, syntax test eder, sadece test geçince kurulum yapar.
# Test başarısız olursa otomatik geri alma yapar.

set -e

SYMBOLS_FILE="/usr/share/X11/xkb/symbols/tr"
RULES_FILE="/usr/share/X11/xkb/rules/evdev.xml"
SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
SNIPPET_FILE="$SCRIPT_DIR/../src/tr-ottoman-snippet.xkb"
BACKUP_DIR="/usr/share/X11/xkb/backup-$(date +%Y%m%d-%H%M%S)"

# Renkler
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "=================================================="
echo "  Osmanlıca Transkripsiyon Klavyesi — Kurulum"
echo "=================================================="
echo ""

# 1) Root kontrolü
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}HATA${NC}: 'sudo bash $0' ile çalıştırın."
    exit 1
fi

# 2) Snippet dosyası mevcut mu?
if [ ! -f "$SNIPPET_FILE" ]; then
    # Alternatif yol: aynı dizinde olabilir
    SNIPPET_FILE="$SCRIPT_DIR/tr-ottoman-snippet.xkb"
    if [ ! -f "$SNIPPET_FILE" ]; then
        echo -e "${RED}HATA${NC}: tr-ottoman-snippet.xkb bulunamadı."
        echo "Aranan yollar:"
        echo "  $SCRIPT_DIR/../src/tr-ottoman-snippet.xkb"
        echo "  $SCRIPT_DIR/tr-ottoman-snippet.xkb"
        exit 1
    fi
fi

# 3) Sistem dosyaları mevcut mu?
if [ ! -f "$SYMBOLS_FILE" ] || [ ! -f "$RULES_FILE" ]; then
    echo -e "${RED}HATA${NC}: Sistem XKB dosyaları bulunamadı."
    echo "  $SYMBOLS_FILE"
    echo "  $RULES_FILE"
    echo ""
    echo "xkeyboard-config paketi yüklü mü kontrol edin."
    exit 1
fi

# 4) Daha önce kurulu mu?
if grep -q 'xkb_symbols "ottoman"' "$SYMBOLS_FILE"; then
    echo -e "${YELLOW}UYARI${NC}: 'ottoman' varyantı zaten kurulu görünüyor."
    echo "Yeniden kurmak için önce kaldırın:"
    echo "  sudo bash $SCRIPT_DIR/uninstall.sh"
    exit 1
fi

# 5) xkbcomp mevcut mu?
if ! command -v xkbcomp >/dev/null 2>&1; then
    echo -e "${YELLOW}UYARI${NC}: xkbcomp bulunamadı, syntax testi atlanacak."
    echo "Daha güvenli kurulum için xkbcomp'ı yükleyin:"
    echo "  Fedora:    sudo dnf install xkbcomp"
    echo "  Ubuntu:    sudo apt install x11-xkb-utils"
    echo "  Arch:      sudo pacman -S xkbcomp"
    SKIP_TEST=1
fi

# === KURULUM ===

echo "[1/5] Yedek alınıyor: $BACKUP_DIR"
mkdir -p "$BACKUP_DIR"
cp "$SYMBOLS_FILE" "$BACKUP_DIR/tr"
cp "$RULES_FILE" "$BACKUP_DIR/evdev.xml"

if [ ! -f "$BACKUP_DIR/tr" ] || [ ! -f "$BACKUP_DIR/evdev.xml" ]; then
    echo -e "${RED}HATA${NC}: Yedek alınamadı."
    rm -rf "$BACKUP_DIR"
    exit 1
fi
echo -e "      ${GREEN}✓${NC} Yedek doğrulandı"

# Geri alma fonksiyonu (hata durumunda)
restore_backup() {
    echo -e "${YELLOW}→ Yedekten geri alınıyor...${NC}"
    cp "$BACKUP_DIR/tr" "$SYMBOLS_FILE"
    cp "$BACKUP_DIR/evdev.xml" "$RULES_FILE"
    echo -e "${GREEN}✓ Geri alındı${NC}"
}

# 6) symbols dosyasına ekle
echo "[2/5] XKB tanımı ekleniyor..."
echo "" >> "$SYMBOLS_FILE"
cat "$SNIPPET_FILE" >> "$SYMBOLS_FILE"
echo -e "      ${GREEN}✓${NC} Eklendi"

# 7) Syntax testi
if [ -z "$SKIP_TEST" ]; then
    echo "[3/5] XKB syntax testi..."
    TEST_KEYMAP=$(mktemp /tmp/xkb-test-XXXXXX.xkb)
    TEST_OUT=$(mktemp /tmp/xkb-test-XXXXXX.xkm)

    cat > "$TEST_KEYMAP" <<EOF
xkb_keymap {
  xkb_keycodes  { include "evdev+aliases(qwerty)" };
  xkb_types     { include "complete" };
  xkb_compat    { include "complete" };
  xkb_symbols   { include "pc+tr(ottoman)+inet(evdev)" };
  xkb_geometry  { include "pc(pc105)" };
};
EOF

    TEST_RESULT=0
    xkbcomp -xkb "$TEST_KEYMAP" "$TEST_OUT" 2>"$TEST_OUT.err" || TEST_RESULT=$?
    ERRORS=$(grep -iE "error|expected|undefined" "$TEST_OUT.err" 2>/dev/null | grep -v "No symbols defined" | grep -v "redefined" || true)

    rm -f "$TEST_KEYMAP" "$TEST_OUT" "$TEST_OUT.err"

    if [ -n "$ERRORS" ] || [ $TEST_RESULT -ne 0 ]; then
        echo -e "      ${RED}✗ Syntax testi başarısız${NC}"
        echo ""
        echo "Hatalar:"
        echo "$ERRORS"
        restore_backup
        exit 1
    fi
    echo -e "      ${GREEN}✓${NC} Syntax testi geçti"
else
    echo "[3/5] Syntax testi atlandı (xkbcomp yok)"
fi

# 8) evdev.xml düzenleme
echo "[4/5] evdev.xml içine GUI kaydı ekleniyor..."
python3 <<'PYEOF' || { echo "Python hatası"; exit 1; }
import re, sys

rules_path = "/usr/share/X11/xkb/rules/evdev.xml"

with open(rules_path, 'r', encoding='utf-8') as f:
    content = f.read()

pattern = r'(<layout>\s*<configItem>\s*<name>tr</name>.*?</configItem>\s*<variantList>)(.*?)(\s*</variantList>\s*</layout>)'
match = re.search(pattern, content, re.DOTALL)

if not match:
    print("      ✗ Türkçe layout bulunamadı")
    sys.exit(1)

if 'ottoman' in match.group(2):
    print("      Zaten kayıtlı, atlandı")
    sys.exit(0)

new_variant = """
      <variant>
        <configItem>
          <name>ottoman</name>
          <description>Turkish (Ottoman, IA transliteration)</description>
          <languageList>
            <iso639Id>tur</iso639Id>
            <iso639Id>ota</iso639Id>
          </languageList>
        </configItem>
      </variant>"""

new_content = (
    content[:match.start(0)]
    + match.group(1)
    + match.group(2)
    + new_variant
    + match.group(3)
    + content[match.end(0):]
)

with open(rules_path, 'w', encoding='utf-8') as f:
    f.write(new_content)

print("      ✓ Eklendi")
PYEOF

# 9) XML doğrulaması
echo "[5/5] evdev.xml doğrulanıyor..."
if ! python3 -c "import xml.etree.ElementTree as ET; ET.parse('$RULES_FILE')" 2>/dev/null; then
    echo -e "      ${RED}✗ XML bozuldu${NC}"
    restore_backup
    exit 1
fi
echo -e "      ${GREEN}✓${NC} XML geçerli"

# Tamam!
echo ""
echo "=================================================="
echo -e "${GREEN}✓ Kurulum başarıyla tamamlandı${NC}"
echo "=================================================="
echo ""
echo "Yedek konumu: $BACKUP_DIR"
echo ""
echo "Sonraki adımlar:"
echo "  1. Logout/login yapın"
echo "  2. Klavye ayarlarınızdan Ottoman varyantını ekleyin:"
echo "     - GNOME: Settings → Keyboard → Input Sources → +"
echo "     - KDE:   System Settings → Input Devices → Keyboard"
echo "     - XFCE:  Klavye Ayarları → Düzen"
echo "  3. Turkish → 'Turkish (Ottoman, IA transliteration)' seçin"
echo "  4. Süper+Boşluk ile geçiş yapın"
echo ""
echo "Kaldırma için:    sudo bash $SCRIPT_DIR/uninstall.sh"
echo "Tuş haritası için: docs/tus-haritasi.md"
echo ""
