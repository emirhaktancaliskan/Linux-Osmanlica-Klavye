# Tuş Haritası

Türkçe Q klavye tabanlıdır. Tüm normal Türkçe yazım (ı, i, ç, ğ, ö, ş, ü) **aynen çalışır**.
Transkripsiyon karakterleri **AltGr (sağ Alt)** ile yazılır.

## Uzun ünlüler (macron)

| Tuş | Küçük | Büyük |
|---|---|---|
| AltGr + A | ā | Ā |
| AltGr + E | ē | Ē |
| AltGr + İ (noktalı i) | ī | Ī |
| AltGr + O | ō | Ō |
| AltGr + U | ū | Ū |

**Önemli:** ī için noktalı i tuşunu kullanın (klavyede ş'nin solu). Noktasız ı tuşu DOKUNULMAMIŞTIR — Türkçe yazım için kritik.

Uzun ı için bileşik karakter gerekir: `ı` + `AltGr+4` → **ı̄**

## Şapkalı ünlüler

| Tuş | Küçük | Büyük |
|---|---|---|
| AltGr + 1 | â | Â |
| AltGr + 2 | î | Î |
| AltGr + 3 | û | Û |

## Vurgulu ünsüzler (alt nokta)

| Tuş | Küçük | Büyük | Karşılığı |
|---|---|---|---|
| AltGr + S | ṣ | Ṣ | ṣād |
| AltGr + D | ḍ | Ḍ | ḍād |
| AltGr + T | ṭ | Ṭ | ṭı |
| AltGr + Z | ẓ | Ẓ | ẓı |
| AltGr + H | ḥ | Ḥ | ḥā |
| AltGr + K | ḳ | Ḳ | ḳāf |

## Hırıltı / gırtlak

| Tuş | Küçük | Büyük | Karşılığı |
|---|---|---|---|
| AltGr + X | ḫ | Ḫ | ḫı |
| AltGr + Q | ġ | Ġ | ġayn |

## Alt-çizgili / nokta varyantı ünsüzler

| Tuş | Küçük | Büyük | Açıklama |
|---|---|---|---|
| AltGr + 5 | ẕ | Ẕ | zel |
| AltGr + 6 | ḏ | Ḏ | zel'in d alternatifi |
| AltGr + 9 | ż | Ż | ḍād'ın z alternatifi |

## Nazal n (sağır kef)

| Tuş | Karakter |
|---|---|
| AltGr + W | ñ (küçük) |
| AltGr + Shift + W | Ñ (büyük) |

## Bileşik karakterler

Bazı transkripsiyon karakterleri Unicode'da tek karakter olarak yoktur, iki kod noktasından oluşur. Önce harfi yazın, sonra ilgili "birleşik" tuşa basın.

| Tuş | İşlev | Kullanım |
|---|---|---|
| AltGr + 4 | birleşik üst macron (U+0304) | `ı` + AltGr+4 → **ı̄** |
| AltGr + 7 | birleşik alt çizgi (U+0331) | `s` + AltGr+7 → **s̱** |

## Ayn ve hemze (TDV resmi)

| Tuş | Karakter | Unicode |
|---|---|---|
| AltGr + , (virgül) | ʿ ayn | U+02BF |
| AltGr + . (nokta) | ʾ hemze | U+02BE |

## Sezgisel mantık özeti

Tuş seçimleri keyfi değil, sezgisel mantığa dayanır:

- **A E İ O U** → kendi macron'lu hâlleri (ā ē ī ō ū)
- **S D T Z H K** → kendi alt-noktalı hâlleri (ṣ ḍ ṭ ẓ ḥ ḳ)
- **X = ḫ, Q = ġ, W = ñ** → Türkçe Q'da boş tuşlar, transkripsiyon için kullanıldı
- **1 2 3** → şapkalı ünlüler (â î û)
- **5 6 9** → alt-çizgili / nokta varyantları
- **4 = üst macron, 7 = alt çizgi** → bileşik karakterler için
- **, ve .** → ayn ve hemze (küçük üst işaretler için noktalama tuşları)

## Test cümlesi

Klavye doğru çalışıyor mu test etmek için:

```
ā ē ī ō ū   ı̄   â î û   ṣ ḍ ṭ ẓ ḥ ḳ   ḫ ġ   ñ Ñ   ẕ ḏ ż   s̱   ʿ ʾ
```

Bileşikler:
- ı̄ → `ı` + AltGr+4
- s̱ → `s` + AltGr+7

## Görsel klavye haritası

Komut satırından düzenin görselini görmek için:

```bash
gkbd-keyboard-display -l "tr(ottoman)"
```
