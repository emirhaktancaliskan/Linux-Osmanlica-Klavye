# Sorun Giderme

## ACİL: Klavye tamamen bozuldu

Eğer kurulum sonrası klavye yanlış karakterler basıyor veya tamamen çalışmıyorsa:

### 1. Yedekten geri yükle (terminale girebiliyorsanız)

```bash
sudo bash scripts/uninstall.sh
```

Sonra logout/login.

### 2. TTY üzerinden geri yükle (terminale yazamıyorsanız)

**Ctrl + Alt + F3** ile TTY3'e geçin (F3-F6 arası deneyin). Burada İngilizce klavye çalışır. Kullanıcı adı/şifre girin, sonra:

```bash
sudo dnf reinstall -y xkeyboard-config
sudo reboot

# Ubuntu/Debian'da:
sudo apt install --reinstall -y xkeyboard-config && sudo reboot

# Arch'ta:
sudo pacman -S xkeyboard-config
sudo reboot
```

Bu komut tüm XKB dosyalarını fabrika ayarlarına döndürür.

## Klavye seçeneklerinde Ottoman görünmüyor

### Kontrol 1: Kurulum tamamlandı mı?

```bash
grep -c "ottoman" /usr/share/X11/xkb/symbols/tr
grep -c "ottoman" /usr/share/X11/xkb/rules/evdev.xml
```

Her ikisi de **1 veya daha fazla** dönmelidir. 0 dönerse kurulum yarım kalmış.

### Kontrol 2: Logout/login yapıldı mı?

XKB değişiklikleri **sadece yeni bir oturum açıldığında** algılanır. Tarayıcıyı kapatmak yetmez, GNOME/KDE'den çıkış yapıp tekrar girmelisiniz.

### Kontrol 3: dconf önbelleği

GNOME bazen klavye listesini önbellekler. Şu komutla zorla yenileyin:

```bash
dconf reset /org/gnome/desktop/input-sources/sources
```

Sonra Settings'ten klavyeleri yeniden ekleyin.

## Bazı tuşlar yanlış karakter basıyor

### Caps Lock açık olabilir

XKB seviyeleri Caps Lock + AltGr kombinasyonunda farklı davranır. Caps Lock kapalı olarak deneyin.

### Yanlış klavye düzeni aktif

Üst paneldeki dil göstergesini kontrol edin:
- **tr** = Türkçe Q (varsayılan)
- **tr ottoman** veya benzeri = Ottoman varyantı

**Süper + Boşluk** ile geçiş yapın.

### Klavye modeli yanlış

Bazı klavyelerde "Right Alt" tuşu "AltGr" olarak çalışmaz. Test edin:

```bash
xev | grep -i keysym
```

Sağ Alt'a basın. Çıktıda `ISO_Level3_Shift` görmelisiniz. Görmüyorsanız:

```bash
gsettings set org.gnome.desktop.input-sources xkb-options "['lv3:ralt_switch']"
```

## Bileşik karakterler (s̱, ı̄) çalışmıyor

### Yazım sırası önemli

- Önce harfi yazın (`s` veya `ı`)
- Sonra birleşik tuşu (AltGr+7 veya AltGr+4)
- Aralarda başka tuş basmayın

### Yazı tipi destekliyor mu?

Varsayılan sistem yazı tipleri (DejaVu, Liberation) bileşik diakritikleri tutarsız gösterebilir. **Gentium Plus** veya **Charis SIL** kurun:

```bash
sudo dnf install sil-gentium-fonts
sudo apt install fonts-sil-gentiumplus
```

LibreOffice'te varsayılan yazı tipini Gentium Plus yapın.

## LibreOffice'te karakter farklı görünüyor

LibreOffice bazen otomatik düzeltme ile özel karakterleri değiştirir. Kapatma yolu:

Araçlar → Otomatik Düzeltme Seçenekleri → Seçenekler sekmesi → "Akıllı tırnak" ve "Çift karakter düzelt" işaretlerini kaldırın.

## Wayland'da setxkbmap çalışmıyor

Bu beklenen durumdur. Wayland'da klavye düzeni dconf üzerinden yönetilir:

```bash
gsettings set org.gnome.desktop.input-sources sources "[('xkb', 'tr+ottoman'), ('xkb', 'tr')]"
```

## evdev.xml bozulmuş olabilir

Kontrol:

```bash
python3 -c "import xml.etree.ElementTree as ET; ET.parse('/usr/share/X11/xkb/rules/evdev.xml'); print('XML geçerli')"
```

"XML geçerli" yazmıyorsa dosya bozuk. `uninstall.sh` veya `dnf reinstall xkeyboard-config` ile düzeltin.

## Hâlâ çözülmedi mi?

[Issues](../../issues) sekmesinden bildirin. Şu bilgileri ekleyin:

```bash
# Bu çıktıları issue'ya yapıştırın:
cat /etc/os-release
echo "---"
echo $XDG_SESSION_TYPE
echo $XDG_CURRENT_DESKTOP
echo "---"
gnome-shell --version 2>/dev/null || plasmashell --version 2>/dev/null
echo "---"
grep -A 30 'xkb_symbols "ottoman"' /usr/share/X11/xkb/symbols/tr | head -40
echo "---"
gsettings get org.gnome.desktop.input-sources sources 2>/dev/null
```
