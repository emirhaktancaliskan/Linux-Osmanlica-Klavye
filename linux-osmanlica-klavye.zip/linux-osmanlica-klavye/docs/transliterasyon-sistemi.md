# Transliterasyon Sistemi

Bu klavye **TDV İslam Ansiklopedisi (İA)** transliterasyon sistemine göre tasarlanmıştır. Türkiye'deki akademik yayınların büyük çoğunluğu bu sistemi kullanır.

## Karakter karşılıkları

| Arap harfi | Latin | Tuş kombinasyonu |
|---|---|---|
| ا | a, ā | a / AltGr+a |
| ب | b | b |
| پ | p | p |
| ت | t | t |
| ث | s̱ | s + AltGr+7 |
| ج | c | c |
| چ | ç | ç |
| ح | ḥ | AltGr+h |
| خ | ḫ | AltGr+x |
| د | d | d |
| ذ | ẕ | AltGr+5 |
| ر | r | r |
| ز | z | z |
| ژ | j | j |
| س | s | s |
| ش | ş | ş |
| ص | ṣ | AltGr+s |
| ض | ḍ | AltGr+d |
| ط | ṭ | AltGr+t |
| ظ | ẓ | AltGr+z |
| ع | ʿ | AltGr+, |
| غ | ġ | AltGr+q |
| ف | f | f |
| ق | ḳ | AltGr+k |
| ك | k | k |
| گ | g | g |
| ڭ | ñ | AltGr+w |
| ل | l | l |
| م | m | m |
| ن | n | n |
| و | v, u, ū, o, ō | v / u / AltGr+u / o / AltGr+o |
| ه | h | h |
| ى | y, ı, i, ī | y / ı / i / AltGr+i |
| ء | ʾ | AltGr+. |

## Ayn ve hemze hakkında

İA sisteminde:

- **Ayn**: `ʿ` (U+02BF MODIFIER LETTER LEFT HALF RING)
- **Hemze**: `ʾ` (U+02BE MODIFIER LETTER RIGHT HALF RING)

Bu karakterler **kesme işareti (')** veya **tırnak (')** ile karıştırılmamalıdır. Yanlış karakter kullanılırsa:

- Akademik dizgi bozuk görünür
- Metin içi arama çalışmaz
- Bibliyografya düzenleme programları (Zotero, Mendeley) hatalı sıralama yapar

Bu klavye doğru karakterleri otomatik üretir, manuel ekleme gerekmez.

## Diğer transliterasyon sistemleri

İA dışında akademik dünyada kullanılan başlıca sistemler:

| Sistem | Bölge | İA'dan farkı |
|---|---|---|
| **DMG** (Deutsche Morgenländische Gesellschaft) | Almanya, Şarkiyat | ǧ (cim için), ġ aynı, č/š kullanır |
| **IJMES** (International Journal of Middle East Studies) | ABD, uluslararası | Türkçe ünlüler yok, Arapça odaklı |
| **EI** (Encyclopaedia of Islam, Brill) | Hollanda, uluslararası | Eski EI2 dh ḏ; yeni EI3 farklı |
| **ALA-LC** (Library of Congress) | ABD kütüphaneleri | Bibliyografi standardı |

Bu sistemler için ek varyantlar geliştirilmesi planlanıyor (bkz. [CONTRIBUTING.md](../CONTRIBUTING.md)).

## Kaynaklar

- [TDV İslam Ansiklopedisi Yazım Esasları](https://islamansiklopedisi.org.tr/)
- Türk Dil Kurumu, *Yazım Kılavuzu*, son baskı
- Halil İnalcık (ed.), *Osmanlı Tarihi Araştırmaları*: bibliyografya ve transliterasyon notları
