# Dağıtım ve Masaüstü Ortamı Uyumluluğu

## Test edilmiş dağıtımlar

| Dağıtım | Sürüm | Durum | Notlar |
|---|---|---|---|
| Fedora | 43 | ✅ Tam | GNOME 49 + Wayland'da test edildi |
| Ubuntu | 24.04+ | ✅ Beklenen | Test sürecinde |
| Debian | 12+ | ✅ Beklenen | Test sürecinde |
| Arch Linux | rolling | ✅ Beklenen | Test sürecinde |
| Linux Mint | 22+ | ✅ Beklenen | Cinnamon ile çalışmalı |
| openSUSE | Tumbleweed | ✅ Beklenen | Test sürecinde |
| Manjaro | rolling | ✅ Beklenen | Arch tabanlı |
| Pop!_OS | 22.04+ | ✅ Beklenen | Ubuntu tabanlı |
| EndeavourOS | rolling | ✅ Beklenen | Arch tabanlı |

Bilinen sınırlamalar: **Immutable dağıtımlar** (Fedora Silverblue/Kinoite, openSUSE MicroOS, Vanilla OS) `/usr` salt okunur olduğundan standart kurulum çalışmaz. Bu dağıtımlar için ayrı bir yöntem gerekir (planlanan: `rpm-ostree usroverlay` veya `etc/X11/xkb` overlay).

## Masaüstü ortamı uyumluluğu

### Tam destekli

Aşağıdaki masaüstü ortamlarında **kurulum sonrası ayarlardan klavye düzenini seçmek** yeterlidir:

| Ortam | X11 | Wayland | Klavye seçim yolu |
|---|---|---|---|
| GNOME | ✅ | ✅ | Settings → Keyboard → Input Sources |
| KDE Plasma | ✅ | ✅ | System Settings → Input Devices → Keyboard |
| XFCE | ✅ | – | Klavye Ayarları → Düzen |
| Cinnamon | ✅ | – | Sistem Ayarları → Klavye |
| MATE | ✅ | – | Klavye Tercihleri |
| LXQt | ✅ | – | Klavye ve Fare → Klavye Düzeni |
| Budgie | ✅ | ✅ | Budgie Settings → Klavye |

### Manuel yapılandırma gerektiren

Aşağıdaki tiling/minimal ortamlar yapılandırma dosyasından klavye düzenini ayarlar:

**Sway** (`~/.config/sway/config`):
```
input * {
    xkb_layout "tr"
    xkb_variant "ottoman"
}
```

**Hyprland** (`~/.config/hypr/hyprland.conf`):
```
input {
    kb_layout = tr
    kb_variant = ottoman
}
```

**i3 + sx/startx** (`~/.xinitrc` veya autostart):
```bash
setxkbmap -layout tr -variant ottoman
```

## Ekran kilidi / GDM / SDDM

Bazı dağıtımlarda kullanıcı oturumundaki klavye düzeni, kilit ekranı veya giriş yöneticisi ekranı için **otomatik geçerli olmaz**. Bu durum sadece şifre girişi için sorun yaratır (Türkçe Q'ya geçmek gerekebilir), günlük kullanımı etkilemez.

GDM (GNOME) için sistem geneli ayar:
```bash
sudo localectl set-x11-keymap tr pc105 ottoman
```

## Sürüm bazlı dikkat noktaları

### GNOME 45+
Wayland varsayılan, X11 oturumu kaldırılma sürecinde. Bu klavye Wayland'da sorunsuz çalışır.

### Ubuntu 24.04 öncesi
`xkeyboard-config` 2.40 öncesi sürümlerde `level3(ralt_switch)` davranışı farklı olabilir. Sorun yaşanırsa paketi güncelleyin.

### Wayland kompozitörleri
Bazı kompozitörler (özellikle wlroots tabanlı) `evdev.lst` dosyasını da okur. Standart kurulum scripti şu an sadece `evdev.xml`'e yazıyor; sorun yaşarsanız [Issues](../../issues) bildirin.

## Bilinen sorunlar

- **Flatpak uygulamalar**: Bazı Flatpak uygulamalar host klavye düzenini doğru almayabilir, çözüm yolu `--socket=wayland` izni veya XDG portal güncellemesi.
- **Snap uygulamalar**: Aynı sorun bazen Snap'lerde de görülür. `snap connect` ile portal bağlantısını kontrol edin.
- **VirtualBox/VMware misafir sistemler**: Misafir eklentilerinin klavye düzenlemesi ana sistemden bağımsız, klavyeyi misafir sistemde de kurmanız gerekir.

Sizin ortamınızda çalışmıyorsa lütfen [Issues](../../issues) sekmesinden bildirin — uyumluluk listesi sizinle gelişir.
